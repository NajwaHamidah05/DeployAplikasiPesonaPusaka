package com.capstone.pesonapusaka.ui.onboarding

data class OnBoardingItem(
    val title: String,
    val img: Int
)
