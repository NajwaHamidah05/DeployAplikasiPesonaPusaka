package com.capstone.pesonapusaka.data.model

data class Story(
    val nama: String? = null,
    val tanggal: String? = null,
    val story: String? = null,
    val fotoStory: String? = null
)
